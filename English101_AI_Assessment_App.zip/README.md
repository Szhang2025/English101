# English 101 AI Assessment App

## What this prototype does

- Responsive single-page English 101 student app
- Course-material review modules
- AI Study Coach
- Multiple-choice, true/false, short-answer, and essay questions
- Browser draft saving
- Automatic scoring of objective questions
- Submission to Google Sheets through Google Apps Script
- Optional instructor Gmail notification
- Optional Gemini-powered AI tutor

## Google setup

### 1. Create the spreadsheet

Create a Google Sheet, for example:

`English 101 Assessment Results`

Open **Extensions → Apps Script**.

### 2. Install the server code

Copy `Code.gs` into the Apps Script editor.

Change:

`YOUR_INSTRUCTOR_GMAIL@gmail.com`

to the instructor's actual Gmail address.

### 3. Optional: enable the AI tutor

Create a Gemini API key and store it in:

**Apps Script → Project Settings → Script Properties**

Property:

`GEMINI_API_KEY`

Value:

your Gemini API key

Do not put the API key in `index.html`.

### 4. Deploy

In Apps Script:

**Deploy → New deployment → Web app**

Use:

- Execute as: **Me**
- Who has access: **Anyone**

Copy the resulting `/exec` URL.

### 5. Connect the HTML app

Open `index.html` and replace:

`PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE`

with the `/exec` URL.

Then open `index.html` in a browser, or host it with GitHub Pages/another static web host.

## Sheet structure

The script automatically creates:

`Submissions`

with columns:

Timestamp, Quiz ID, Course, Student Name, Student Email,
Objective Score, Comments, Q1–Q8

The Q1–Q6 values are currently stored as answer-choice indexes. You can
change the JavaScript to store the answer text instead.

## Recommended production improvements

Before using this for a high-stakes course assessment:

- Add authentication or a course-specific access code.
- Add a unique submission ID.
- Prevent duplicate submissions.
- Move question banks to a separate JSON/Google Sheet.
- Add instructor-only dashboard authentication.
- Add server-side validation and rate limiting.
- Add explicit student consent/privacy language.
- Store only the student data the institution actually requires.
- Use your institution's approved AI/data-processing policy.
- Consider FERPA/institutional requirements before sending student work to any AI provider.
