/******************************************************
 * ENGLISH 101 ASSESSMENT APP — GOOGLE APPS SCRIPT
 *
 * SETUP
 * 1. Create a Google Sheet for assessment submissions.
 * 2. Extensions > Apps Script.
 * 3. Paste this file into Code.gs.
 * 4. Change INSTRUCTOR_EMAIL.
 * 5. Optionally set GEMINI_API_KEY in Script Properties.
 * 6. Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone
 * 7. Copy the /exec URL into index.html:
 *    CONFIG.APPS_SCRIPT_URL
 *
 * The first submission creates a sheet named "Submissions".
 ******************************************************/

const INSTRUCTOR_EMAIL = "YOUR_INSTRUCTOR_GMAIL@gmail.com";
const SHEET_NAME = "Submissions";
const GEMINI_MODEL = "gemini-2.5-flash";

function doGet() {
  return json({ok:true,service:"English 101 Assessment API"});
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || "{}");
    if (data.action === "submitAssessment") return submitAssessment(data);
    if (data.action === "askAI") return askAI(data);
    throw new Error("Unknown action");
  } catch (err) {
    return json({ok:false,error:String(err)});
  }
}

function submitAssessment(d) {
  if (!d.studentName || !d.studentEmail) throw new Error("Student name and email are required.");

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);

  const headers = [
    "Timestamp","Quiz ID","Course","Student Name","Student Email",
    "Objective Score","Comments","Q1","Q2","Q3","Q4","Q5","Q6","Q7","Q8"
  ];
  if (sh.getLastRow() === 0) sh.appendRow(headers);

  const a = d.answers || {};
  const row = [
    new Date(), d.quizId || "", d.course || "", d.studentName, d.studentEmail,
    d.score === "" ? "" : d.score + "/6", d.comments || "",
    a.q1||"",a.q2||"",a.q3||"",a.q4||"",a.q5||"",a.q6||"",a.q7||"",a.q8||""
  ];
  sh.appendRow(row);

  // Optional instructor notification.
  if (INSTRUCTOR_EMAIL && !INSTRUCTOR_EMAIL.includes("YOUR_")) {
    const subject = "English 101 Assessment Submitted — " + d.studentName;
    const body =
      "A new English 101 assessment was submitted.\n\n" +
      "Student: " + d.studentName + "\n" +
      "Email: " + d.studentEmail + "\n" +
      "Quiz: " + (d.quizId || "") + "\n" +
      "Score: " + (d.score === "" ? "Needs review" : d.score + "/6") + "\n\n" +
      "The full response is available in the Google Sheet.";
    MailApp.sendEmail(INSTRUCTOR_EMAIL, subject, body);
  }

  return json({ok:true});
}

function askAI(d) {
  if (!d.question) throw new Error("Question is required.");

  // Keep the AI grounded in the course materials.
  const systemPrompt = `
You are the English 101 Study Coach.
Help students understand writing concepts using the course topics below:
- rhetorical situation: writer, audience, purpose, context, message
- thesis statements: focused, specific, debatable claims
- evidence and analysis
- paragraph organization and topic sentences
- revision versus proofreading
- academic integrity and responsible source use

You may explain concepts, demonstrate similar examples, ask guiding questions,
and generate practice exercises. Do NOT answer active quiz questions, write a
submission for the student, or help a student evade academic-integrity rules.
If the student appears to be asking for an answer to an active assessment,
redirect them to explanation or a similar practice example.
Use clear, supportive college-level language.
`;
  const key = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");
  if (!key) {
    return json({ok:true,answer:"The AI service is not configured yet. Add GEMINI_API_KEY in Apps Script → Project Settings → Script Properties."});
  }

  const url = "https://generativelanguage.googleapis.com/v1beta/models/" +
              encodeURIComponent(GEMINI_MODEL) + ":generateContent?key=" + encodeURIComponent(key);

  const payload = {
    systemInstruction:{parts:[{text:systemPrompt}]},
    contents:[{role:"user",parts:[{text:d.question}]}],
    generationConfig:{temperature:0.4,maxOutputTokens:700}
  };

  const response = UrlFetchApp.fetch(url,{
    method:"post",contentType:"application/json",
    payload:JSON.stringify(payload),muteHttpExceptions:true
  });
  const code = response.getResponseCode();
  const text = response.getContentText();
  if(code < 200 || code >= 300) throw new Error("Gemini API error: "+text);

  const obj = JSON.parse(text);
  const answer = obj.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("") ||
                 "I could not generate a response.";
  return json({ok:true,answer:answer});
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
